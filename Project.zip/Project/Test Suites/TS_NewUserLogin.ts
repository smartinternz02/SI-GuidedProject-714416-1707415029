<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS_NewUserLogin</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>3d894f69-7a23-4cc5-8049-a0c4738e662c</testSuiteGuid>
   <testCaseLink>
      <guid>bdbfbbd8-1883-4325-b754-95501dcc08e1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <iterationNameVariable>
         <defaultValue>''</defaultValue>
         <description></description>
         <id>2e893ac5-7695-492a-be46-b9cefc497646</id>
         <masked>false</masked>
         <name>Name</name>
      </iterationNameVariable>
      <testCaseId>Test Cases/DataDriven Testing/TC_001_NewUserLogin</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>b0942941-6334-4103-bffe-b0bf497a996b</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/NewUserExcelFile</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>b0942941-6334-4103-bffe-b0bf497a996b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>name</value>
         <variableId>2e893ac5-7695-492a-be46-b9cefc497646</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>b0942941-6334-4103-bffe-b0bf497a996b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>email </value>
         <variableId>ab6c45ae-1a19-4e1b-b34e-c7b31ea9a522</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>b0942941-6334-4103-bffe-b0bf497a996b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>password </value>
         <variableId>992bfaa9-5e08-4466-ae40-88b0eec63b7f</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
