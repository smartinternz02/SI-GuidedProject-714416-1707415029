<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Mens Jeans</name>
   <tag></tag>
   <elementGuidId>cc89b6c7-6566-4f96-943a-6faf0cbdc910</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='n/1045564']/span/a/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>a91f1c43-33e1-4bd4-ac0e-0a980b9e49fd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-size-base a-color-base</value>
      <webElementGuid>36f1a321-ef6b-44ba-b06d-93442cc21dfb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Men's Jeans</value>
      <webElementGuid>6440fd34-f819-4c08-a271-d841f231afaa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;n/1045564&quot;)/span[@class=&quot;a-list-item&quot;]/a[@class=&quot;a-link-normal s-navigation-item&quot;]/span[@class=&quot;a-size-base a-color-base&quot;]</value>
      <webElementGuid>ad75ed31-5086-4c25-a5fd-316ea9bae8b9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='n/1045564']/span/a/span</value>
      <webElementGuid>597f2f06-6d62-44aa-aef1-4dae67149a4f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Men', &quot;'&quot;, 's Clothing')])[1]/following::span[2]</value>
      <webElementGuid>5e523ae1-23e3-496b-a07a-ee53f19cfd3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department'])[1]/following::span[6]</value>
      <webElementGuid>cac826d7-290d-4eab-8e09-c2847ba97d7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Women', &quot;'&quot;, 's Clothing')])[1]/preceding::span[1]</value>
      <webElementGuid>7b785852-a1a6-4a0c-9933-2e6887013e69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Women', &quot;'&quot;, 's Jeans')])[1]/preceding::span[3]</value>
      <webElementGuid>1580102f-2863-4de8-af03-e2195d68b261</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/span/a/span</value>
      <webElementGuid>7999e108-cd0e-4d80-b90f-e0fd93942bc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = concat(&quot;Men&quot; , &quot;'&quot; , &quot;s Jeans&quot;) or . = concat(&quot;Men&quot; , &quot;'&quot; , &quot;s Jeans&quot;))]</value>
      <webElementGuid>3fe85746-d32e-463e-b58f-f087557918a2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
