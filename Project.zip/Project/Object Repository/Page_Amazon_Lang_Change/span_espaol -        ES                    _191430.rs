<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_espaol -        ES                    _191430</name>
   <tag></tag>
   <elementGuidId>e46f40ce-77b7-4232-9297-2df6cd196f86</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='icp-language-settings']/div[3]/div/label/span/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>20ac9a88-2045-42f6-9f98-468b2790f7f7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>dir</name>
      <type>Main</type>
      <value>ltr</value>
      <webElementGuid>24b4ab48-5ec0-438a-9c5d-6b05c3d85e35</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        español -
        ES

        
            
                    
            

            
                
                    - Traducción
                
            
        
    </value>
      <webElementGuid>686396b6-a2db-42c7-bd9a-74c005aaa238</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-language-settings&quot;)/div[@class=&quot;a-row a-spacing-mini&quot;]/div[@class=&quot;a-radio a-radio-fancy&quot;]/label[1]/span[@class=&quot;a-label a-radio-label&quot;]/span[1]</value>
      <webElementGuid>13e6c9d6-eb6d-4929-9269-ff063d83d6e2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='icp-language-settings']/div[3]/div/label/span/span</value>
      <webElementGuid>5663ed7c-6665-40bf-b3e5-c87fb99c74ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/label/span/span</value>
      <webElementGuid>1d9f3be7-96d4-4ba6-a966-5ab32d97bfa3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        español -
        ES

        
            
                    
            

            
                
                    - Traducción
                
            
        
    ' or . = '
        español -
        ES

        
            
                    
            

            
                
                    - Traducción
                
            
        
    ')]</value>
      <webElementGuid>36bca6b8-d41b-4048-a69e-22339824897b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
